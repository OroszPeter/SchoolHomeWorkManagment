namespace SchoolHomeWorkManagmentWebAPI.DTOs;

public class MediaUploadDto
{
    public IFormFile Data { get; set; }
}