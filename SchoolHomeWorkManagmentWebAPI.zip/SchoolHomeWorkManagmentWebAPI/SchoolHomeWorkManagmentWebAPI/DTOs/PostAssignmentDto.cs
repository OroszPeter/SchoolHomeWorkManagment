namespace SchoolHomeWorkManagmentWebAPI.DTOs;

public class PostAssignmentDto
{
    public string AssignmentName { get; set; } // Feladat neve
    public string Description { get; set; } // Feladat leírása
    public DateTime DueDate { get; set; } // Beadási határidő
}
