namespace SchoolHomeWorkManagmentWebAPI.DTOs;

public class SubmissionAssignmentDto
{
    public int Id { get; set; }
    public string AssignmentName { get; set; }
}