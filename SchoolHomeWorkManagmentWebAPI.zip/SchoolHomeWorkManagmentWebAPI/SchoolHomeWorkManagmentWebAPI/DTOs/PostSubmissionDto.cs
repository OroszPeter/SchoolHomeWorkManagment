namespace SchoolHomeWorkManagmentWebAPI.DTOs;

public class PostSubmissionDto
{
    public string SubmissionLink { get; set; } // Link a beadott feladathoz
    public string UserId { get; set; } // A felhasználó azonosítója
    public int AssignmentId { get; set; } // Az assignment azonosítója
}