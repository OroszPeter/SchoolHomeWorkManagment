using SchoolHomeWorkManagmentWebAPI.Entities;

namespace SchoolHomeWorkManagmentWebAPI.DTOs;

public class AssignmentDto
{
    public int Id { get; set; }
    public string AssignmentName { get; set; } // Feladat neve
    public string Description { get; set; } // Feladat leírása
    public DateTime DueDate { get; set; } // Beadási határidő
    public List<string>? MediaFiles { get; set; } = new List<string>(); // Letöltési linkek
    
}
