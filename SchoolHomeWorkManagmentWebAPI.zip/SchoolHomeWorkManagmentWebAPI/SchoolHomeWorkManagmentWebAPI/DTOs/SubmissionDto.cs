namespace SchoolHomeWorkManagmentWebAPI.DTOs;

public class SubmissionDto
{
    public int Id { get; set; }
    public string SubmissionLink { get; set; }
    public DateTime SubmittedAt { get; set; }
    public int Grade { get; set; }
    public string UserId { get; set; }
    public UserDto User { get; set; }
    public int AssignmentId { get; set; }
    public SubmissionAssignmentDto Assignment { get; set; }
}