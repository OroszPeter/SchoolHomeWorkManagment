using SchoolHomeWorkManagmentWebAPI.DbContext;
using SchoolHomeWorkManagmentWebAPI.DTOs;

namespace SchoolHomeWorkManagmentWebAPI.Controllers;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SchoolHomeWorkManagmentWebAPI.Entities;

[Route("api/[controller]")]
[ApiController]
public class SubmissionsController(ApplicationDbContext context) : ControllerBase
{

    // GET: api/submissions
    [Authorize]
    [HttpGet("get-all")]
    public async Task<ActionResult<IEnumerable<SubmissionDto>>> GetSubmissions()
    {
        var submissions = await context.Submissions
            .Include(s => s.User) // Betöltjük a User-t
            .Include(s => s.Assignment) // Betöltjük az Assignment-et
            .Select(s => new SubmissionDto
            {
                Id = s.Id,
                SubmissionLink = s.SubmissionLink,
                SubmittedAt = s.SubmittedAt,
                Grade = s.Grade,
                UserId = s.UserId,
                User = new UserDto
                {
                    FirstName = s.User.FirstName,
                    LastName = s.User.LastName
                },
                AssignmentId = s.AssignmentId,
                Assignment = new SubmissionAssignmentDto
                {
                    Id = s.Assignment.Id,
                    AssignmentName = s.Assignment.AssignmentName
                }
            })
            .ToListAsync();

        return Ok(submissions);
    }


    // POST: api/submissions
    [Authorize]
    [HttpPost("post")]
    public async Task<ActionResult<Submission>> PostSubmission(PostSubmissionDto postSubmissionDto)
    {
        // Ellenőrizzük, hogy létezik-e az adott feladat (Assignment) és felhasználó (User)
        var assignment = await context.Assignments.FindAsync(postSubmissionDto.AssignmentId);
        if (assignment == null)
        {
            return NotFound(new { message = "Assignment not found." });
        }

        var user = await context.Users.FindAsync(postSubmissionDto.UserId);
        if (user == null)
        {
            return NotFound(new { message = "User not found." });
        }

        // Új Submission létrehozása
        var submission = new Submission
        {
            SubmissionLink = postSubmissionDto.SubmissionLink,
            SubmittedAt = DateTime.UtcNow, // Beadás dátuma automatikusan aktuális idő
            UserId = postSubmissionDto.UserId,
            AssignmentId = postSubmissionDto.AssignmentId,
            Grade = 0 // Alapértelmezett értékelés
        };

        // Submission mentése
        context.Submissions.Add(submission);
        await context.SaveChangesAsync();

        // Visszatérés a létrehozott Submission-nel
        return Ok("Submission added.");
    }

}
