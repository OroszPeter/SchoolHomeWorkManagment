using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SchoolHomeWorkManagmentWebAPI.DbContext;
using SchoolHomeWorkManagmentWebAPI.DTOs;
using SchoolHomeWorkManagmentWebAPI.Entities;

namespace SchoolHomeWorkManagmentWebAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AssignmentsController(ApplicationDbContext context) : ControllerBase
{
    [Authorize]
    [HttpGet("get-all")]
    public async Task<ActionResult<IEnumerable<AssignmentDto>>> GetAssignments()
    {
        var assignments = await context.Assignments
                                                .Include(a => a.MediaFiles)
                                                .Include(a => a.Submissions)
                                                .ToListAsync();

        var assignmentDtos = assignments.Select(a =>
            new AssignmentDto
            {
                Id = a.Id,
                AssignmentName = a.AssignmentName,
                Description = a.Description,
                DueDate = a.DueDate,
                //Submissions = a.Submissions, // A feltöltések változatlanul maradnak
                MediaFiles = a.MediaFiles!.Select(m => Url.Action("DownloadMedia", "Media", new { id = m.Id }, Request.Scheme)).ToList()! // Letöltési linkek generálása
            }).ToList();

        return Ok(assignmentDtos);
    }


    [Authorize]
    [HttpPost("create")]
    public async Task<ActionResult<Assignment>> PostAssignment(PostAssignmentDto postAssignmentDto)
    {
        // Új Assignment létrehozása a DTO alapján
        var assignment = new Assignment
        {
            AssignmentName = postAssignmentDto.AssignmentName,
            Description = postAssignmentDto.Description,
            DueDate = postAssignmentDto.DueDate
        };

        // Assignment mentése az adatbázisba
        context.Assignments.Add(assignment);
        await context.SaveChangesAsync();

        // Visszaadjuk a létrehozott Assignment-et
        return CreatedAtAction(nameof(GetAssignmentById), new { id = assignment.Id }, assignment.Id);
    }

    [Authorize]
    [HttpGet("{id}")]
    public async Task<ActionResult<AssignmentDto>> GetAssignmentById(int id)
    {
        // Keresés az Assignment ID alapján
        var assignment = await context.Assignments
            .Include(a => a.MediaFiles) // Ha szükséges, a MediaFiles betöltése
            .Include(a => a.Submissions) // Ha szükséges, a Submissions betöltése
            .FirstOrDefaultAsync(a => a.Id == id);

        if (assignment == null)
        {
            return NotFound(); // Ha nem található, 404-es hiba
        }

        // DTO létrehozása
        var assignmentDto = new AssignmentDto
        {
            Id = assignment.Id,
            AssignmentName = assignment.AssignmentName,
            Description = assignment.Description,
            DueDate = assignment.DueDate,
            // Submissions = assignment.Submissions, // Ha szeretnéd, hogy a feltöltések is benne legyenek
            MediaFiles = assignment.MediaFiles!.Select(m => Url.Action("DownloadMedia", "Media", new { id = m.Id }, Request.Scheme)).ToList()!
        };

        return Ok(assignmentDto); // DTO visszaadása
    }





}