using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SchoolHomeWorkManagmentWebAPI.DbContext;
using SchoolHomeWorkManagmentWebAPI.DTOs;
using SchoolHomeWorkManagmentWebAPI.Entities;

namespace SchoolHomeWorkManagmentWebAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class MediaController(ApplicationDbContext context) : ControllerBase 
{

    // Média fájl feltöltése
    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpPost("upload")]
    public async Task <IActionResult> UploadMedia(MediaUploadDto file) 
    {
        if (file.Data is null || file.Data.Length == 0) 
        {
            return BadRequest("Nincs feltöltött fájl.");
        }

        // Média entitás létrehozása
        var media = new Media 
        {
            FileName = file.Data.FileName,
            MimeType = file.Data.ContentType
        };

        using(var memoryStream = new MemoryStream()) 
        {
            await file.Data.CopyToAsync(memoryStream);
            media.Data = memoryStream.ToArray(); // BLOB-ként tárolás
        }

        context.MediaFiles.Add(media);
        await context.SaveChangesAsync();
        
        return Ok();
    }

    [Authorize]
    [HttpPost("{id}/upload")]
    public async Task<IActionResult> UploadMedia(int id, [FromForm] List<IFormFile> files)
    {
        var assignment = await context.Assignments.Include(a => a.MediaFiles).FirstOrDefaultAsync(a => a.Id == id);

        if (assignment == null)
        {
            return NotFound();
        }

        foreach (var file in files)
        {
            if (file.Length > 0)
            {
                using (var memoryStream = new MemoryStream())
                {
                    await file.CopyToAsync(memoryStream);
                    var media = new Media
                    {
                        FileName = file.FileName,
                        MimeType = file.ContentType,
                        Data = memoryStream.ToArray() // A fájl tartalmát BLOB-ként tároljuk
                    };
                    assignment.MediaFiles!.Add(media);
                }
            }
        }

        await context.SaveChangesAsync();
        var message = (files.Count  > 1) ? $"Fájlok sikeresen feltöltve." : $"Fájl sikeresen feltöltve.";
        return Ok(message);
    }


    [ApiExplorerSettings(IgnoreApi = true)]
    [HttpGet]
    public async Task<IActionResult> GetAllMedia()
    {
        var mediaFiles = await context.MediaFiles
            .Select(m => new 
            { 
                m.Id, 
                m.FileName, 
                m.MimeType 
            })
            .ToListAsync();

        return Ok(mediaFiles);
    }

    
    [HttpGet("download/{id}")]
    public async Task<IActionResult> DownloadMedia(int id)
    {
        // Keressük meg az adott fájlt az adatbázisban
        var media = await context.MediaFiles.FindAsync(id);
        if (media == null)
        {
            return NotFound("A fájl nem található.");
        }

        // Visszaadjuk a fájlt
        return File(media.Data, media.MimeType, media.FileName);
    }
}