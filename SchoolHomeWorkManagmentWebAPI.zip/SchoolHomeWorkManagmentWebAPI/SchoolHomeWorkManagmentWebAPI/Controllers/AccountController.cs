using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using SchoolHomeWorkManagmentWebAPI.DTOs;
using SchoolHomeWorkManagmentWebAPI.Entities;

namespace SchoolHomeWorkManagmentWebAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AccountController(
    UserManager<User> userManager,
    RoleManager<IdentityRole> roleManager,
    IConfiguration config) : ControllerBase
{

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterDto register)
    {
        var newUser = new User() 
        { 
            FirstName =  register.Firstname,
            LastName = register.Lastname,
            ClassName = register.Classname,
            Email = register.Email,
            PasswordHash = register.Password,
            UserName = register.Email.Split('@')[0]
        };
    
        var user = await userManager.FindByEmailAsync(newUser.Email);
        
        if (user is not null)
        {
            return BadRequest("Ez a felhasználó már regisztrálva van.");
        }

        var createUser = await userManager.CreateAsync(newUser, register.Password);

        var checkAdmin = await roleManager.FindByNameAsync("Admin");
        
        if (checkAdmin is null)
        {
            await roleManager.CreateAsync(new IdentityRole() { Name = "Admin" });
            await userManager.AddToRoleAsync(newUser, "Admin");
            return Ok("Admin felhasználó létrehozva.");
        }

        var checkUser = await roleManager.FindByNameAsync("User");

        if (checkUser is null)
        {
            await roleManager.CreateAsync(new IdentityRole() { Name = "User" });
        }

        await userManager.AddToRoleAsync(newUser, "User");
        
        return Ok("Felhasználó létrehozva.");
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginDto login)
    {
        if (login is null)
        {
            return BadRequest("Üres bejelentkezési paraméterek.");
        }

        var user = await userManager.FindByNameAsync(login.Username);
        
        if (user is null)
        {
            return NotFound("Nincs ilyen felhasználónév.");
        }

        bool checkUserPasswords = await userManager.CheckPasswordAsync(user, login.Password);
        
        if (!checkUserPasswords)
        {
            return BadRequest("Helytelen belépés.");
        }

        var userRole = await userManager.GetRolesAsync(user);

        string token = GenerateToken(user.Id, user.UserName, user.Email, userRole.First());
        
        var response = new 
        {
            token,
            user = new 
            {
                id = user.Id,
                username = user.UserName,
                email = user.Email,
                role = userRole.First()
            }
        };

        return Ok(response);

    }

    
    [HttpGet("get-user-role")]
    public async Task<IActionResult> GetUserRole()
    {
        // Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
        if (User.Identity is not { IsAuthenticated: true })
        {
            return Unauthorized("A felhasználó nincs bejelentkezve.");
        }

        // Lekérjük a bejelentkezett felhasználó adatait a Claims-ből
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (userId is null)
        {
            return NotFound("Felhasználói azonosító nem található.");
        }

        // Megkeressük az adatbázisban a felhasználót
        var user = await userManager.FindByIdAsync(userId);
        if (user is null)
        {
            return NotFound("Felhasználó nem található.");
        }

        // Lekérjük a felhasználó szerepkörét
        var roles = await userManager.GetRolesAsync(user);

        // Feltételezzük, hogy a felhasználónak legalább egy szerepköre van
        if (roles.Count == 0)
        {
            return NotFound("Felhasználói szerepkör nem található.");
        }

        return Ok(new { role = roles.First() });
    }


    private string GenerateToken(string id, string name, string email, string role)
    {
        var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!));
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
        var userClaims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, id),
            new Claim(ClaimTypes.Name, name),
            new Claim(ClaimTypes.Email, email),
            new Claim(ClaimTypes.Role, role)
        };
        var token = new JwtSecurityToken(
            issuer: config["Jwt:Issuer"],
            audience: config["Jwt:Audience"],
            claims: userClaims,
            expires: DateTime.Now.AddDays(1),
            signingCredentials: credentials
        );
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}