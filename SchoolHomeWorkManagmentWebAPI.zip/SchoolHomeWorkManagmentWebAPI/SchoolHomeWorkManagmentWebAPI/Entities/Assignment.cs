namespace SchoolHomeWorkManagmentWebAPI.Entities;

public class Assignment
{
    public int Id { get; set; }
    public string AssignmentName { get; set; } // Feladat neve
    public string Description { get; set; } // Feladat leírása
    public DateTime DueDate { get; set; } // Beadási határidő
    public virtual List<Media>? MediaFiles { get; set; } = new List<Media>(); // Opcionális képfájlok
    public virtual List<Submission> Submissions { get; set; } = new List<Submission>(); // Felhasználók feltöltései
}
