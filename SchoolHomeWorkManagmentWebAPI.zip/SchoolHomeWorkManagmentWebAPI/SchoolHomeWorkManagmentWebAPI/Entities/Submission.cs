namespace SchoolHomeWorkManagmentWebAPI.Entities;

public class Submission
{
    public int Id { get; set; }
    public string SubmissionLink { get; set; } // Link a beadott feladathoz
    public DateTime SubmittedAt { get; set; } // Beadás dátuma
    public int Grade { get; set; } // Értékelés (null, ha nincs még értékelve)
    
    public string UserId { get; set; }
    public virtual User User { get; set; } // Felhasználó, aki feltöltötte

    public int AssignmentId { get; set; }
    public virtual Assignment Assignment { get; set; } // Hozzárendelt feladat
}
