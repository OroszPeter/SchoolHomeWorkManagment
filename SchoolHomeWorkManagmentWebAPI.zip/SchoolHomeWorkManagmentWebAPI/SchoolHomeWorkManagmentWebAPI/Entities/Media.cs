namespace SchoolHomeWorkManagmentWebAPI.Entities;

public class Media
{
    public int Id { get; set; }
    public string FileName { get; set; } // A fájl neve
    public string MimeType { get; set; } // A fájl típusának megadása (pl. image/jpeg)
    public byte[] Data { get; set; } // A fájl tartalma BLOB-ként
}
