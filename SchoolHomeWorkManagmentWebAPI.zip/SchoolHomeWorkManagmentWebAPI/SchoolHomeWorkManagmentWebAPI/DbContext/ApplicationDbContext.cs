using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SchoolHomeWorkManagmentWebAPI.Entities;

namespace SchoolHomeWorkManagmentWebAPI.DbContext;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : IdentityDbContext<User>(options)
{
    public DbSet<Assignment> Assignments { get; set; } // Assignment entitás DbSet
    public DbSet<Media> MediaFiles { get; set; } // Media entitás DbSet
    public DbSet<Submission> Submissions { get; set; } // Submission entitás DbSet

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Assignment entitás konfigurálása
        modelBuilder.Entity<Assignment>()
            .HasMany(a => a.MediaFiles)
            .WithOne()
            .OnDelete(DeleteBehavior.Cascade); // Ha az Assignment törlődik, a hozzá tartozó Media is törlődik

        modelBuilder.Entity<Assignment>()
            .HasMany(a => a.Submissions)
            .WithOne(s => s.Assignment)
            .OnDelete(DeleteBehavior.Cascade); // Ha az Assignment törlődik, a hozzá tartozó Submission is törlődik

        modelBuilder.Entity<Submission>()
            .HasOne(s => s.User)
            .WithMany() // Felhasználó esetében több Submission is lehet
            .HasForeignKey(s => s.UserId)
            .OnDelete(DeleteBehavior.Restrict); // A felhasználó törlése nem törli a Submission-öket
    }
}